#include <stdio.h>

//perpangkatan
long long int square(long long int num, long long int square){
	long long int total = num;
	for(int i = 2; i <= square; ++i){
		total = total * num;
		printf("loop %d: %lld\n", i, total);
	}
	return total;
}

int  main(){
	long long int testcase, a, b, n, res = 0;
	
	scanf("%d", &testcase);
	
	for(int loop = 1; loop <= testcase; loop++){
		scanf("%lld %lld %lld", &n, &a, &b);
		
		res = square(a, b);
		printf("main: %lld\n", res);
		
//		int x = 100000; //looping while
//		while(x > 1){
//			
//		}
		
	}
	
	return 0;
}

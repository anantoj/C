#include <stdio.h>

long long pangkat(int num, int p){
	while(p >= 1 ){
		num *= num;
		p--;
	}
	num = num % 1000000007;
	return num;
}

int main(){
	int testcase, a, b;
	long long int num1 , num2, result;
	scanf("%d", &testcase);
	
	for(int loop = 1; loop <= testcase ; loop++){
		num1 = 2;
		num2 = 3;
		scanf("%d %d", &a, &b);
		
		num1 = pangkat(num1, a);
		num2 = pangkat(num2, b);
		result = (num1 * num2) % 1000000007;
		printf("%d\n", result);
	}
	
	return 0;
}

#include <stdio.h>

int main(){
char word1[25];
char word2[25];

scanf("%s %s", word1, word2);
printf("%s%s\n", word1, word2);

}
